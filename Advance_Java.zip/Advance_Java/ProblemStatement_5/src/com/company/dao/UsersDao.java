package com.company.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import com.company.dbutil.MyDB;
import com.company.model.Users;

public class UsersDao {
	public int addUser(Users u)
	{
		int check = 0;
		Connection con = new MyDB().getConnection();
		PreparedStatement pst = null;
		String sql = "INSERT INTO users(first_name,address,email,user_name,password,registration_date) VALUES(?,?,?,?,?,?)";
//		String reg_date = "date('"+new Date()+"')";
		
		try {
			pst = con.prepareStatement(sql);
			pst.setString(1, u.getFirst_name());
			pst.setString(2, u.getAddress());
			pst.setString(3, u.getEmail());
			pst.setString(4, u.getUser_name());
			pst.setString(5, u.getPassword());
			pst.setDate(6, java.sql.Date.valueOf(java.time.LocalDate.now()));
			check = pst.executeUpdate();
		} catch(SQLException e) {
			e.printStackTrace();
		} finally {
			new MyDB().closeConnection(pst, con);
		}
		return check;
	}
	public Users verifyUser(String user_name, String password)
	{
		Connection con = new MyDB().getConnection();
		PreparedStatement pst = null;
		ResultSet rs = null;
		String sql = "select * from users where user_name=? and password=?";
//		date('2016-11-08')
		Users u = null;
		try {
			pst = con.prepareStatement(sql);
			pst.setString(1, user_name);
			pst.setString(2, password);
			rs = pst.executeQuery();
			while(rs.next())
			{
				u = new Users();
				
				u.setFirst_name((String)rs.getObject("first_name"));
				u.setAddress((String)rs.getObject("address"));
				u.setEmail((String)rs.getObject("email"));
				u.setUser_name((String)rs.getObject("user_name"));
				u.setRegistration_date((String)rs.getObject("registration_date").toString());				
			}
		} catch(SQLException e) {
			e.printStackTrace();
		} finally {
			new MyDB().closeConnection(rs, pst, con);
		}
		return u;
	}
	
	public Users resetUser(String user_name, String email)
	{
		Connection con = new MyDB().getConnection();
		PreparedStatement pst = null;
		ResultSet rs = null;
		String sql = "select * from users where user_name=? and email=?";
//		date('2016-11-08')
		Users u = null;
		try {
			pst = con.prepareStatement(sql);
			pst.setString(1, user_name);
			pst.setString(2, email);
			rs = pst.executeQuery();
			while(rs.next())
			{
				u = new Users();
				
				u.setFirst_name((String)rs.getObject("first_name"));
				u.setAddress((String)rs.getObject("address"));
				u.setEmail((String)rs.getObject("email"));
				u.setUser_name((String)rs.getObject("user_name"));
				u.setRegistration_date((String)rs.getObject("registration_date").toString());				
			}
		} catch(SQLException e) {
			e.printStackTrace();
		} finally {
			new MyDB().closeConnection(rs, pst, con);
		}
		return u;
	}
	
	public int setPassword(Users u, String password)
	{
		int check = 0;
		Connection con = new MyDB().getConnection();
		PreparedStatement pst = null;

		String sql = "update users set password=? where user_name=? and email=?";

		try {
			pst = con.prepareStatement(sql);
			pst.setString(1, password);
			pst.setString(2, u.getUser_name());
			pst.setString(3, u.getEmail());
			check = pst.executeUpdate();
		} catch(SQLException e) {
			e.printStackTrace();
		} finally {
			new MyDB().closeConnection(pst, con);
		}
		return check;
	}
}
