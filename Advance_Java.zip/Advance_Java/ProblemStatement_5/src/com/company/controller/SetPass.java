package com.company.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.company.dao.UsersDao;
import com.company.model.Users;

@WebServlet("/SetPass")
public class SetPass extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		if(request.getParameter("setpass").equals("Submit")) {
			String new_password = request.getParameter("new_password");
			String confirm_password = request.getParameter("confirm_password");
			Users u = (Users)request.getSession().getAttribute("user"); 
			if(new_password.equals(confirm_password))
			{
				if(new UsersDao().setPassword(u, confirm_password)>0)
				{
					request.getSession().invalidate();
					response.getWriter().println("<center><h3 style=\"color:red;\">Password Reset Successfully !!!<br>Please Login With new Credentials</h3></center>");
					request.getRequestDispatcher("login.jsp").include(request, response);
				}				
			} else {
				response.getWriter().println("<center><h3 style=\"color:red;\">Please Check Your details again</h3></center>");
				request.getRequestDispatcher("set_pass.jsp").include(request, response);
			}
		}
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
}
