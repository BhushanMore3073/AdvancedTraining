package com.company.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.company.dao.UsersDao;
import com.company.model.Users;

@WebServlet("/UserController")
public class UserController extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		if (request.getParameter("b1").equals("Login")) {
			if (!(request.getParameter("username").isEmpty()) && !(request.getParameter("password").isEmpty())) {
				Users u = new UsersDao().verifyUser(request.getParameter("username"), request.getParameter("password"));
				if (u != null) {
					request.getSession().setAttribute("user", u);
					request.getRequestDispatcher("welcome.jsp").forward(request, response);
				} else {
					response.getWriter().println("<center><h3 style=\"color:red;\">Bad Credential's!</h3></center>");
					request.getRequestDispatcher("login.jsp").include(request, response);
				}
			} else {
				response.getWriter().println("<center><h3 style=\"color:red;\">Bad Credential's!</h3></center>");
				request.getRequestDispatcher("login.jsp").include(request, response);
			}
		}
		if (request.getParameter("b1").equals("Reg")) {
			request.getRequestDispatcher("register.jsp").forward(request, response);
		}
		if (request.getParameter("b1").equals("Register")) {
			String first_name = request.getParameter("first_name");
			String address = request.getParameter("address");
			String user_name = request.getParameter("user_name");
			String password = request.getParameter("password");
			String email = request.getParameter("email");
			Users u = new Users();
			u.setFirst_name(first_name);
			u.setAddress(address);
			u.setEmail(email);
			u.setPassword(password);
			u.setUser_name(user_name);
			if (new UsersDao().addUser(u) > 0) {
				request.getSession().setAttribute("user", new UsersDao().verifyUser(user_name, password));
				request.getRequestDispatcher("welcome.jsp").forward(request, response);
			} else {
				response.getWriter().println("<center><h3 style=\"color:red;\">Registration Failed !!!</h3></center>");
				request.getRequestDispatcher("register.jsp").include(request, response);
			}
		}
		if (request.getParameter("b1").equals("Logout")) {
			request.getSession().invalidate();
			request.getRequestDispatcher("welcome.jsp").forward(request, response);
		}
		if (request.getParameter("b1").equals("Forgot Password")) {
//			logic for forgot password
			request.getRequestDispatcher("reset_password.jsp").forward(request, response);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
