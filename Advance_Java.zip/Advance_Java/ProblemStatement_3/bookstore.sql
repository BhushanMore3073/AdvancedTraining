-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 02, 2022 at 01:50 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bookstore`
--

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `Book_id` int(11) NOT NULL,
  `Book_name` varchar(50) NOT NULL,
  `Auther` varchar(20) NOT NULL,
  `Price` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`Book_id`, `Book_name`, `Auther`, `Price`) VALUES
(1, 'Let Us C', 'Yashavant P. Kanetka', 200),
(2, 'Thinking in Java', 'Thinking in Java', 300),
(3, 'Computer Networkig', 'James F. Kurose', 250),
(4, 'Head First C#', 'Andrew Stellman', 400),
(5, 'What is HTML5', 'Brett McLaughlin', 300),
(6, 'HTML5 in Action', 'Joe Lennon', 569),
(7, 'OOP with C++', 'Balagurusamy', 308),
(8, 'C++:The Complete Reference', 'Herbert Schildt', 532),
(9, 'Head First SQL', 'Lynn Beighley', 450),
(10, 'SQL:The Complete Reference', 'James Groff', 667);

-- --------------------------------------------------------

--
-- Table structure for table `order_details`
--

CREATE TABLE `order_details` (
  `Order_Id` int(11) NOT NULL,
  `Book_Id` int(11) NOT NULL,
  `Cust_Name` varchar(20) NOT NULL,
  `Phone_No` varchar(10) NOT NULL,
  `Address` varchar(50) NOT NULL,
  `Order_Date` date NOT NULL,
  `Quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `order_details`
--

INSERT INTO `order_details` (`Order_Id`, `Book_Id`, `Cust_Name`, `Phone_No`, `Address`, `Order_Date`, `Quantity`) VALUES
(1, 1, 'Amit', '9673960407', 'Radhika Vihar', '2016-11-08', 3),
(2, 2, 'Mona', '875451395', 'Rakshak Nagar', '2016-11-08', 3),
(3, 3, 'Kavi', '7845127845', 'Rakshak Nagar Gold', '2016-11-08', 2),
(4, 4, 'Monalisa', '784512788', 'Bangalore', '2016-11-08', 3),
(5, 5, 'Amol', '784578215', 'Wadganosheri', '2016-11-08', 3),
(6, 6, 'Amit', '78521868', 'Bangalore', '2016-11-08', 2);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `first_name` varchar(10) NOT NULL,
  `address` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `user_name` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `registration_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`first_name`, `address`, `email`, `user_name`, `password`, `registration_date`) VALUES
('Amit', 'Wagholi', 'amit.mishra369@gmail.com', '9673960407', 'mona9Dutta', '2016-11-08'),
('Hari', 'Chandan Nagar', 'hari39@rediffmail.com', '7845127421', 'Adam99@', '2016-11-08'),
('Monalisa', 'Rakshak Nagar', 'mona9@gmail.com', '9878454503', 'pinaki9@', '2016-11-08'),
('Narendra', 'Rajpath', 'narendra17@pmo.nic.in', '8877990011', 'Delhi9%', '2016-11-08'),
('Kavita', 'Rakshak Nagar Gold', 'kavi23@gmail.com', '9878521402', 'Alia8&', '2016-11-08');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`Book_id`);

--
-- Indexes for table `order_details`
--
ALTER TABLE `order_details`
  ADD PRIMARY KEY (`Order_Id`),
  ADD KEY `Book_Id` (`Book_Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `Book_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `order_details`
--
ALTER TABLE `order_details`
  MODIFY `Order_Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `order_details`
--
ALTER TABLE `order_details`
  ADD CONSTRAINT `order_details_ibfk_1` FOREIGN KEY (`Book_Id`) REFERENCES `books` (`Book_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
