package com.company.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.company.dao.BooksDao;
import com.company.dao.OrderDetailsDao;
import com.company.model.Books;
import com.company.model.OrderDetails;

public class BookController extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		if(request.getParameter("b1").equals("Get Book")) {
			Books b = new BooksDao().getBookById(Integer.parseInt(request.getParameter("id")));
			request.getSession().setAttribute("book", b);
			request.getRequestDispatcher("quantityDetails.jsp").forward(request, response);
		}
		if(request.getParameter("b1").equals("Purchase")) {
			Books b = (Books)request.getSession().getAttribute("book");
			int required_quantity = 0;
			int available_quantity = new BooksDao().getQuantityByBookId(b.getBook_Id()); 
			if(!request.getParameter("quantity").isBlank()) {
				required_quantity = Integer.parseInt(request.getParameter("quantity"));
				if(required_quantity<available_quantity)
				{
					request.getSession().setAttribute("quantity", required_quantity);
					request.getRequestDispatcher("confirmPurchase.jsp").forward(request, response);				
				}
				else {
					response.getWriter().println("<center><h1>"+
							"Available quantity for this book is "+
							"<b>"+available_quantity+"</b>"+
							"</h1></center>"
							);
					request.getRequestDispatcher("quantityDetails.jsp").include(request, response);
				}
			}
			else
			{
				response.getWriter().println("<center><h1>"+
						"Please Enter A <b>quantity</b>"+
						"</h1></center>"
						);
				request.getRequestDispatcher("quantityDetails.jsp").include(request, response);
			}
		}
		if(request.getParameter("b1").equals("Confirm")) {
			String cust_name,address,phone_no;
			cust_name=request.getParameter("cust_name");
			address = request.getParameter("address");
			phone_no = request.getParameter("phone_number");
			Books b = (Books)request.getSession().getAttribute("book");
			int quantity = (int)request.getSession().getAttribute("quantity");
			OrderDetails o = new OrderDetails();
			o.setAddress(address);
			o.setBook_Id(b.getBook_Id());
			o.setCust_Name(cust_name);
			o.setPhone_No(phone_no);
			o.setQuantity(quantity);
			System.out.println(o);
			if(new OrderDetailsDao().addOrderDetails(o)>0)
				request.getRequestDispatcher("success.jsp").include(request, response);
			else {
				response.getWriter().println("<center><h1>"+
						"System Failed to order"+
						"</h1></center>"
						);
				request.getRequestDispatcher("confirmPurchase.jsp").include(request, response);
			}
		}
		if(request.getParameter("b1").equals("Cancel")) {
			request.getRequestDispatcher("welcome.jsp").forward(request, response);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
