package com.company.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.company.dbutil.MyDB;
import com.company.model.OrderDetails;

public class OrderDetailsDao {
	public int addOrderDetails(OrderDetails o)
	{
		String sql ="INSERT INTO order_details(Book_Id,Cust_Name,Phone_No,Address,Order_Date,Quantity)VALUES(?,?,?,?,?,?)";
//		date('2016-11-08')
		new BooksDao().updateBooksQuantity(o.getBook_Id(), o.getQuantity());
		Connection con = new MyDB().getConnection();
		PreparedStatement pst = null;
		int check = 0;
		try {
			pst = con.prepareStatement(sql);
			pst.setInt(1, o.getBook_Id());
			pst.setString(2, o.getCust_Name());
			pst.setString(3, o.getPhone_No());
			pst.setString(4, o.getAddress());
			pst.setDate(5, java.sql.Date.valueOf(java.time.LocalDate.now()));
			pst.setInt(6, o.getQuantity());
			check = pst.executeUpdate();
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			new MyDB().closeConnection(pst, con);
		}
		return check;
	}
}
