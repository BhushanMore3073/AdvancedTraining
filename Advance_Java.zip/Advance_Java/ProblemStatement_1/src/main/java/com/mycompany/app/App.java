package com.mycompany.app;

import java.util.Scanner;

import com.mycompany.dao.ProductDao;
import com.mycompany.domain.Product;

public class App {
	public static void main(String[] args) {
		while (true) {
			System.out.println(
					"A. View Products\nB. Add Product\nC. Update Product\nD. Delete Product\nE. Search Proudct\nF. Exit");
			System.out.println("=====================================================");
			System.out.println("Enter an Option");
			System.out.println("=====================================================");
			Scanner sc = new Scanner(System.in);
			char choice = sc.next().toLowerCase().charAt(0);

			switch (choice) {
			case 'a': {
				System.out.println("\n\n");
				System.out.println("----------------------------------------------");
				for (Product p : new ProductDao().viewAllProducts()) {
					System.out.println("Product Id : " + p.getProductId());
					System.out.println("Product Name : " + p.getProductName());
					System.out.println("Product Price : " + p.getProductPrice());

					System.out.println("\n\n");
				}
			}
				break;

			case 'b': {
				Product p = new Product();
				System.out.println("\n\n");
				System.out.println("----------------------------------------------");
				System.out.println("Enter Product Id : ");
				System.out.println("----------------------------------------------");
				p.setProductId(new Scanner(System.in).next());
				System.out.println("----------------------------------------------");
				System.out.println("Enter Product Name : ");
				System.out.println("----------------------------------------------");
				p.setProductName(new Scanner(System.in).nextLine());
				System.out.println("----------------------------------------------");
				System.out.println("Enter Product Price : ");
				System.out.println("----------------------------------------------");
				p.setProductPrice(new Scanner(System.in).nextDouble());
				System.out.println("----------------------------------------------");

				if (new ProductDao().addProduct(p) > 0)
					System.out.println("Product added Successfully");
				else
					System.out.println("Error Occured while adding Product");
			}
				break;
			case 'c': {
				Product p = new Product();
				System.out.println("\n\n");
				System.out.println("----------------------------------------------");
				System.out.println("Enter Product Id : ");
				System.out.println("----------------------------------------------");
				p.setProductId(new Scanner(System.in).next());
				System.out.println("----------------------------------------------");
				System.out.println("Enter New Product Name : ");
				System.out.println("----------------------------------------------");
				p.setProductName(new Scanner(System.in).nextLine());
				System.out.println("----------------------------------------------");
				System.out.println("Enter New Product Price : ");
				System.out.println("----------------------------------------------");
				p.setProductPrice(new Scanner(System.in).nextDouble());
				System.out.println("----------------------------------------------");

				if (new ProductDao().updateProduct(p) > 0)
					System.out.println("Product updated Successfully");
				else
					System.out.println("Error Occured while updating Product");
			}
				break;
			case 'd': {
				System.out.println("\n\n");
				System.out.println("----------------------------------------------");
				System.out.println("Enter Product Id : ");
				System.out.println("----------------------------------------------");

				if (new ProductDao().deleteProductById(new Scanner(System.in).next()) > 0)
					System.out.println("Product deleted Successfully");
				else
					System.out.println("Error Occured while deleting  Product");
			}
				break;
			case 'e': {
				System.out.println("\n\n");
				System.out.println("----------------------------------------------");
				System.out.println("Enter Product Id");
				System.out.println("----------------------------------------------");
				Product p = new ProductDao().searchProductById(new Scanner(System.in).next());
				if (p != null) {
					System.out.println("Product Id : " + p.getProductId());
					System.out.println("Product Name : " + p.getProductName());
					System.out.println("Product Price : " + p.getProductPrice());
				} else
					System.out.println("Product Not found !");
			}
				break;
			case 'f':
				System.out.println("\n\n");
				System.out.println("**********************THANK YOU***********************");
				System.exit(0);
				break;
			}
		}
	}
}
