package com.mycompany.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mycompany.dbutil.DBUtils;
import com.mycompany.domain.Product;

public class ProductDao {
	
	public int addProduct(Product p)
	{
		int check = 0;
		Connection con =  new DBUtils().getConnection();
		PreparedStatement pst = null;
		String sql = "insert into product(productId,productName,productPrice) values(?,?,?)";
		try {
			pst = con.prepareStatement(sql);
			pst.setString(1, p.getProductId());
			pst.setString(2, p.getProductName());
			pst.setDouble(3, p.getProductPrice());
			check = pst.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			new DBUtils().closeConnection(pst, con);
		}
		return check;
	}
	
	public int deleteProductById(String id)
	{
		int check = 0;
		Connection con = new DBUtils().getConnection();
		PreparedStatement pst = null;
		String sql = "delete from product where productId=?";
		try {
			pst = con.prepareStatement(sql);
			pst.setString(1, id);
			check = pst.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			new DBUtils().closeConnection(pst, con);
		}
		return check;
	}
	public int updateProduct(Product p)
	{
		int check = 0;
		Connection con = new DBUtils().getConnection();
		PreparedStatement pst = null;
		String sql = "update product set productName=?,productPrice=? where productId=?";
		try {
			pst = con.prepareStatement(sql);
			pst.setString(1, p.getProductName());
			pst.setDouble(2, p.getProductPrice());
			pst.setString(3, p.getProductId());
			check = pst.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			new DBUtils().closeConnection(pst, con);
		}
		return check;
	}
	public Product searchProductById(String id)
	{
		Product p = null;
		Connection con = new DBUtils().getConnection();
		PreparedStatement pst = null;
		ResultSet rs = null;
		String sql = "select * from product where productId=?";
		try {
			pst = con.prepareStatement(sql);
			pst.setString(1, id);
			rs = pst.executeQuery();
			while(rs.next())
			{
				p = new Product();
				p.setProductId((String)rs.getObject("productId"));
				p.setProductName((String)rs.getObject("productName"));
				p.setProductPrice((double)rs.getObject("productPrice"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			new DBUtils().closeConnection(pst, con);
		}
		return p;
	}
	public List<Product> viewAllProducts()
	{
		List<Product> products = new ArrayList<>();
		Connection con = new DBUtils().getConnection();
		PreparedStatement pst = null;
		ResultSet rs = null;
		String sql = "select * from product";
		try {
			pst = con.prepareStatement(sql);
			rs = pst.executeQuery();
			while(rs.next())
			{
				Product p = new Product();
				p.setProductId((String)rs.getObject("productId"));
				p.setProductName((String)rs.getObject("productName"));
				p.setProductPrice((double)rs.getObject("productPrice"));
				
				products.add(p);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			new DBUtils().closeConnection(pst, con);
		}
		return products;
	}
}
