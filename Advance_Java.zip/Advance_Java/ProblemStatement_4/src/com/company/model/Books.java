package com.company.model;

public class Books {
	private int Book_Id;
	private String Book_Name;
	private String Auther;
	private double Price;
	public int getBook_Id() {
		return Book_Id;
	}
	public void setBook_Id(int book_Id) {
		Book_Id = book_Id;
	}
	public String getBook_Name() {
		return Book_Name;
	}
	public void setBook_Name(String book_Name) {
		Book_Name = book_Name;
	}
	public String getAuther() {
		return Auther;
	}
	public void setAuther(String auther) {
		Auther = auther;
	}
	public double getPrice() {
		return Price;
	}
	public void setPrice(double price) {
		Price = price;
	}
	
	public String toString() {
		return "Books [Book_Id=" + Book_Id + ", Book_Name=" + Book_Name + ", Auther=" + Auther + ", Price=" + Price
				+ "]";
	}
}
