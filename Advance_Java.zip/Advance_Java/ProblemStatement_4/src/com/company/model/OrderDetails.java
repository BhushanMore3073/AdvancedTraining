package com.company.model;

public class OrderDetails {
	private int Order_Id;
	private int Book_Id;
	private String Cust_Name;
	private String Phone_No;
	private String Address;
	private String Order_Date;
	private int Quantity;
	public int getOrder_Id() {
		return Order_Id;
	}
	public void setOrder_Id(int order_Id) {
		Order_Id = order_Id;
	}
	public int getBook_Id() {
		return Book_Id;
	}
	public void setBook_Id(int book_Id) {
		Book_Id = book_Id;
	}
	public String getCust_Name() {
		return Cust_Name;
	}
	public void setCust_Name(String cust_Name) {
		Cust_Name = cust_Name;
	}
	public String getPhone_No() {
		return Phone_No;
	}
	public void setPhone_No(String phone_No) {
		Phone_No = phone_No;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public String getOrder_Date() {
		return Order_Date;
	}
	public void setOrder_Date(String order_Date) {
		Order_Date = order_Date;
	}
	public int getQuantity() {
		return Quantity;
	}
	public void setQuantity(int quantity) {
		Quantity = quantity;
	}
	public String toString() {
		return "OrderDetails [Order_Id=" + Order_Id + ", Book_Id=" + Book_Id + ", Cust_Name=" + Cust_Name
				+ ", Phone_No=" + Phone_No + ", Address=" + Address + ", Order_Date=" + Order_Date + ", Quantity="
				+ Quantity + "]";
	}
}
