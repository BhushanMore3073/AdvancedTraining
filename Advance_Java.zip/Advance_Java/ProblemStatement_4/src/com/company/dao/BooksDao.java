package com.company.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.company.dbutil.MyDB;
import com.company.model.Books;

public class BooksDao {
	public List<Books> getAllBooks()
	{
		List<Books> books = new ArrayList<>();
		Connection con = new MyDB().getConnection();
		PreparedStatement pst = null;
		ResultSet rs = null;
		String sql = "select * from books";
		try {
			pst = con.prepareStatement(sql);
			rs = pst.executeQuery();
			while(rs.next())
			{
				Books book = new Books();
				book.setBook_Id((int)rs.getObject("Book_Id"));
				book.setBook_Name((String)rs.getObject("Book_Name"));
				book.setAuther((String)rs.getObject("Auther"));
				book.setPrice((double)rs.getObject("Price"));
				books.add(book);
			}
		} catch(SQLException e)
		{
			e.printStackTrace();
		} finally {
			new MyDB().closeConnection(rs, pst, con);
		}
		return books;
	}
	
	public Books getBookById(int id)
	{
		Books book = null;
		Connection con = new MyDB().getConnection();
		PreparedStatement pst = null;
		ResultSet rs = null;
		String sql = "select * from books where Book_Id=?";
		try {
			pst = con.prepareStatement(sql);
			pst.setInt(1, id);
			rs = pst.executeQuery();
			while(rs.next())
			{
				book = new Books();
				book.setBook_Id((int)rs.getObject("Book_Id"));
				book.setBook_Name((String)rs.getObject("Book_Name"));
				book.setAuther((String)rs.getObject("Auther"));
				book.setPrice((double)rs.getObject("Price"));
			}
		} catch(SQLException e)
		{
			e.printStackTrace();
		} finally {
			new MyDB().closeConnection(rs, pst, con);
		}
		return book;
	}
}
