package com.problem_statement_6.Problem_Statement_6_4;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class TestPhoneBook {
	public static void main(String[] args) {
		Map<String, String> contact = new HashMap<String, String>();
		while(true)
		{
			System.out.println("1)Add new phone book entry\n2)Search Phone Number\n3)Quit");
			System.out.println("Enter Your Choice : ");
			switch(new Scanner(System.in).nextInt())
			{
				case 1:
				{
					System.out.println("Enter Name of Contact : ");
					String name = new Scanner(System.in).nextLine();
					System.out.println("Enter Phone Number");
					String number = new Scanner(System.in).nextLine();
					
					if(name.isBlank() || number.isBlank())
					{
						System.out.println("Please Enter A valid Details");	
						break;
					}
					else
					{
						contact.put(name,number);
						System.out.println("Number Added Successfully !");						
					}
					break;					
				}
				case 2:
				{					
					System.out.println("Enter Name of Contact : ");
					String name = new Scanner(System.in).nextLine();
					if(name.isBlank())
						System.out.println("Please Enter a Valid Name");
					else
						if(contact.containsKey(name))
							System.out.println("Contact Number = "+contact.get(name));
						else
							System.out.println("No contact Found");
					break;
				}
				case 3:
					System.exit(0);
				default :
			}
		}
	}
}
