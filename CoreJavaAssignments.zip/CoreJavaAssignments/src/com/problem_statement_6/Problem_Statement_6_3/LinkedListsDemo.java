package com.problem_statement_6.Problem_Statement_6_3;

import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class LinkedListsDemo {
	public static void main(String[] args) {
		LinkedList<Employee> list = new LinkedList<>();
		while(true)
		{
			System.out.println("1)addInput()\n2)display()\n3)Exit");
			System.out.println("Enter Your choice : ");
			switch(new Scanner(System.in).nextInt())
			{
				case 1:addInput(list);
				break;
				case 2:display(list);
				break;
				case 3:System.exit(0);
				break;
				default:System.out.println("Wrong choice :(");
				break;
			}			
		}
		
	}
	
	public static void addInput(LinkedList<Employee> list)
	{
		System.out.println("Enter Employee No :");
		long employeeNo = new Scanner(System.in).nextLong();
		System.out.println("Enter Employee Name :");
		String empoyeeName = new Scanner(System.in).nextLine();
		System.out.println("Enter Employee Address :");
		String Address = new Scanner(System.in).nextLine();
		
		list.add(new Employee(employeeNo, empoyeeName, Address));
	}
	
	public static void display(LinkedList<Employee> list)
	{
		if(list.size()>0)
		{
			System.out.println("\nList Of Employee in Ascending Order");
			list.listIterator().forEachRemaining(e->System.out.println(e));
			System.out.println("\nList Of Employee in Descending Order");
			list.descendingIterator().forEachRemaining(e->System.out.println(e));
			System.out.println();
		}
		else
			System.out.println("List is Empty");
	}
}
