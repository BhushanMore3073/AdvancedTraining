package com.problem_statement_6.Problem_Statement_6_3;

public class Employee {
	public long employeeNo;
	public String employeeName;
	public String Address;
	
	public Employee() {}
	public Employee(long employeeNo, String employeeName, String address) {
		this.employeeNo = employeeNo;
		this.employeeName = employeeName;
		this.Address = address;
	}
	
	
	public String toString() {
		return "Employee [employeeNo=" + employeeNo + ", employeeName=" + employeeName + ", Address=" + Address + "]";
	}
}
