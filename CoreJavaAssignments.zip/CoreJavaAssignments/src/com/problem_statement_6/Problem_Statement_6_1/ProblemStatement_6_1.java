package com.problem_statement_6.Problem_Statement_6_1;

import java.util.ArrayList;
import java.util.Scanner;

public class ProblemStatement_6_1 {
	public static void main(String[] args) {
		ArrayList<String> students = new ArrayList<>();
		while(true)
		{
			System.out.println("1)Add Student\n2)Display All Student\n3)Find Student\n4)Exit");
			System.out.println("Enter your choice : ");
			switch(new Scanner(System.in).nextInt())
			{
				case 1:
					System.out.println("Enter Student Name : ");
					students.add(new Scanner(System.in).nextLine());
					break;
					
				case 2:
					for(String s:students)
						System.out.println(s);
					break;
					
				case 3:
					System.out.println("Enter Student Name to Find Student:");
					if(students.contains(new Scanner(System.in).nextLine()))
						System.out.println("Student Found");
					else
						System.out.println("Student Not Found");
					break;
					
				case 4:System.exit(1);
				default:System.out.println("Wrong choice");break;
			}
		}
	}
}
