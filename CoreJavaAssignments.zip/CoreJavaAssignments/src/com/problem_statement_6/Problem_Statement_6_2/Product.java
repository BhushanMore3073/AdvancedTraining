package com.problem_statement_6.Problem_Statement_6_2;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Scanner;

public class Product {
	String product_id;
	String product_name;

	Product(String product_id, String product_name) {
		this.product_id = product_id;
		this.product_name = product_name;
	}

	public static void main(String[] args) {
		MyHashSet<Product> products = new MyHashSet<Product>(10);
		products.add(new Product("P001", "Maruti 800"));
		products.add(new Product("P002", "Maruti ZEN"));
		products.add(new Product("P003", "Maruti Dezire"));
		products.add(new Product("P004", "Maruti Alto"));
		products.add(new Product("P005", "Maruti Swift"));
		products.add(new Product("P006", "Maruti Baleno"));
		products.add(new Product("P007", "Maruti Ciaz"));
		products.add(new Product("P008", "Maruti Celerio"));
		products.add(new Product("P009", "Maruti Eeco"));
		products.add(new Product("P010", "Maruti Ertiga"));

		while (true) {
			System.out.println("1)Search Product\n2)Delete Product By Id\n3)Display All Products\n4)Exit");
			System.out.println("_________________________________________________________________________");
			System.out.println("Enter your choice : ");

			switch (new Scanner(System.in).nextInt()) {
			case 1: // Search
				System.out.println("\t1)Search By Id\n\t2)Search By Name");
				System.out.println("\tEnter your choice : ");
				System.out.println("_________________________________________________________________________");
				switch (new Scanner(System.in).nextInt()) {
				case 1:
					System.out.println("Enter Product Id : ");
					String s = new Scanner(System.in).nextLine();
					for(Product p:products)
						if (p.product_id.equals(s))
							System.out.println("Product Found");
					System.out.println("_________________________________________________________________________");
					break;
				case 2:
					System.out.println("Enter Product Name : ");
					String s1 = new Scanner(System.in).nextLine();
					for(Product p:products)
						if (p.product_name.equals(s1))
							System.out.println("Product Found");
					System.out.println("_________________________________________________________________________");
					break;
				default:System.out.println("--------------------  Wrong Choice  --------------------");
				}
				break;
			case 2: // Delete By Id
				System.out.println("Enter Product Id : ");
				String s = new Scanner(System.in).nextLine();
				for(Product p:products)
					if (p.product_id.equals(s))
					{
						System.out.println("Product Found");
						products.remove(p);
						System.out.println("Product removed successfully !");
						break;
					}
				System.out.println("_________________________________________________________________________");
				break;

			case 3:
				products.forEach(p->System.out.println("product id : "+p.product_id+", product name : "+p.product_name));
				System.out.println("_________________________________________________________________________");
				break;
			case 4: // Exit
				System.exit(0);
			default:System.out.println("----------------  Wrong Choice  ----------------------");
			}
		}
	}
}

class MyHashSet<T> extends HashSet<T> {
	private long maxSize;

	public MyHashSet(long maxSize) {
		this.maxSize = maxSize;
	}

	@Override
	public boolean add(T item) {
		if (size() == maxSize) {
			removeFirst();
		}
		return super.add(item);
	}

	private void removeFirst() {
		if (size() > 0) {
			Iterator<T> iterator = iterator();
			T item = iterator.next();
			remove(item);
		}
	}
}
