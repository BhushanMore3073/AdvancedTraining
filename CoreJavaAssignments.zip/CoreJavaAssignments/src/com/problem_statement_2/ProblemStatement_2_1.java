package com.problem_statement_2;

import java.util.Scanner;

public class ProblemStatement_2_1 {
	public static void main(String[] args) {
		System.out.println("Enter a String :");
		String s = new Scanner(System.in).nextLine();
		System.out.println("Length of String is : "+s.length());
		System.out.println("String in Upper Case : "+s.toUpperCase());
		
		String rst = "";
		
		for(int i=s.length()-1;i>=0;i--)
			rst += s.charAt(i);
		System.out.println("\n'This is palindrome checker is not case sensetive'\n");
		if(s.toLowerCase().equals(rst.toLowerCase()))
			System.out.println(s+" is palindrome String");
		else
			System.out.println(s+" is not palindrome String");
	}

}
