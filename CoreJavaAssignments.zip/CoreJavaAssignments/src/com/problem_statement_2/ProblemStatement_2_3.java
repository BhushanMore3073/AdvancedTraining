package com.problem_statement_2;

public class ProblemStatement_2_3 {
	public static void main(String[] args) {
		int A[] = {3, 2, 4, 5, 6, 4, 5, 7, 3, 2, 3, 4, 7, 1, 2, 0, 0, 0};

//		printing actual array
		for(int a:A)
			System.out.print(a+" ");

		
//		sum of element 0 to 14
		int sum=0;
		for(int i=0;i<A.length-4;i++)
			sum+=A[i];
		A[A.length-4]=sum;
		for(int a:A)
			System.out.print(a+" ");
		System.out.println();
		
//		Average of all element
		sum=0;
		for(int i=0;i<A.length;i++)
			sum+=A[i];
		A[A.length-3]=(int)(sum/A.length);
		for(int a:A)
			System.out.print(a+" ");
		System.out.println();
		
//		min element if Array
		int min=A[0];
		for(int i=0;i<A.length;i++)
			if(A[i]<min)
				min=A[i];
		A[A.length-2]=min;
		for(int a:A)
			System.out.print(a+" ");
	}
}
