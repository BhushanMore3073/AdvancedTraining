package com.problem_statement_2;

import java.util.Scanner;

public class ProblemStatement_2_2 {
	public static void main(String[] args) {
		int n1,n2,sum;
		System.out.println("Enter two number's on seperated by line : ");
		n1 = new Scanner(System.in).nextInt();
		n2 = new Scanner(System.in).nextInt();
		
		System.out.print(n1+" "+n2);
		
		for(int i=0;i<13;i++)
		{
			sum = n1+n2;
			n1=n2;
			n2=sum;
			System.out.print(" "+sum);
		}
	}
}
