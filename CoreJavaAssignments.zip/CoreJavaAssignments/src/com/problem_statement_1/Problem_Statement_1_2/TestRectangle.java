package com.problem_statement_1.Problem_Statement_1_2;
import java.util.Scanner;

public class TestRectangle {
	public static void main(String[] args) {
//		one with default values
		System.out.println("with default values");
		Rectangle r1 = new Rectangle();
		System.out.println("Length --> "+r1.getLength()+", Breadth --> "+r1.getBreadth());
		System.out.println("Area of r1 --> "+r1.calculateArea());
		System.out.println("Display method");
		r1.display();
		
//		with user inputs
		System.out.println("\nwith user input");
		Rectangle r2 = new Rectangle();
		System.out.println("Enter length : ");
		r2.setLength(new Scanner(System.in).nextDouble());
		System.out.println("Enter Breadth : ");
		r2.setBreadth(new Scanner(System.in).nextDouble());
		System.out.println("Area of r2 --> "+r2.calculateArea());
		System.out.println("Display method");
		r2.display();

//		passing arguments in constructor
		System.out.println("\npassing values L=20 & B=22 in constructor");
		Rectangle r3 = new Rectangle(20,22);
		System.out.println("Length --> "+r3.getLength()+", Breadth --> "+r3.getBreadth());
		System.out.println("Area of r3 --> "+r3.calculateArea());
		System.out.println("Display method -->");
		r3.display();
		
//		User input's
		System.out.println("\nwith user input");
		Rectangle r4 = new Rectangle();
		System.out.println("Enter length : ");
		r4.setLength(new Scanner(System.in).nextDouble());
		System.out.println("Enter Breadth : ");
		r4.setBreadth(new Scanner(System.in).nextDouble());
		System.out.println("Area of r4 --> "+r4.calculateArea());
		System.out.println("Display method");
		r4.display();
		
		System.out.println("\nwith user input");
		Rectangle r5 = new Rectangle();
		System.out.println("Enter length : ");
		r4.setLength(new Scanner(System.in).nextDouble());
		System.out.println("Enter Breadth : ");
		r4.setBreadth(new Scanner(System.in).nextDouble());
		System.out.println("Area of r4 --> "+r4.calculateArea());
		System.out.println("Display method");
		r4.display();
		
	}
}
