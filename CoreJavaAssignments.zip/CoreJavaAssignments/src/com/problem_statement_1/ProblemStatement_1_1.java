package com.problem_statement_1;

import java.util.Scanner;

public class ProblemStatement_1_1 {
	public static void main(String[] args) {
		System.out.println("Enter the Number n : ");
		int n = new Scanner(System.in).nextInt();
		System.out.println("Even Number's less than or equal to the Number '"+n+"'");
		
		for(int i=1;i<=n;i++)
		{
			if(i%2==0)
				System.out.println("--> "+i);
		}
	}
}
