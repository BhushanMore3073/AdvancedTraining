package com.problem_statement_1.Problem_Statement_1_4;

import java.util.Scanner;

public class TestRectangle {

	public static void main(String[] args) {
//		to demonstrate that length  is greater than 20.0 is initialize to default value 1.0
		Rectangle r = new Rectangle();
		r.setLength(22.2);
		r.setBreadth(14.02);
		r.display();
		
//		to demonstrate Rectangle using user input values
		r = new Rectangle();
		System.out.println("Enter Length : ");
		r.setLength(new Scanner(System.in).nextDouble());
		System.out.println("Enter Breadth : ");
		r.setBreadth(new Scanner(System.in).nextDouble());
		r.display();
	}
}
