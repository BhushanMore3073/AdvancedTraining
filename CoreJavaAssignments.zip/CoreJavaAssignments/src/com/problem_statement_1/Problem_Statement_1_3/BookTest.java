package com.problem_statement_1.Problem_Statement_1_3;

import java.util.Scanner;

public class BookTest {
	public static void main(String[] args) {
		System.out.println("How many Books you want to create ?");
		Book b[] = new Book[new Scanner(System.in).nextInt()];
		for(int i=0;i<b.length;i++)
			b[i]= createBook();
		for(int i=0;i<b.length;i++)
		{
			System.out.println("Enter "+(i+1)+"st Book title :");
			b[i].setBook_title(new Scanner(System.in).nextLine());
			System.out.println("Enetr "+(i+1)+"st Book Price : ");
			b[i].setBook_price(new Scanner(System.in).nextDouble());
		}
		
		System.out.println("Book Details You entered : ");
		System.out.println("Book title \t\t price");
		for(int i=0;i<b.length;i++)
			showBook(b[i]);
	}
	public static Book createBook()
	{
		return new Book();
	}
	public static void showBook(Book b)
	{
		System.out.println(b.getBook_title()+"\t\t"+b.getBook_price());
	}
}
