package com.problem_statement_5;

public class ProblemStatement_5_1 {
	public static void main(String[] args) {
		String str = "JAVA is Simple";
		
		System.out.println(str.toUpperCase());
		System.out.println(str.toLowerCase());
		for(String s:str.split(" "))
			System.out.print(s.charAt(0)+" ");
		
		System.out.println();
		
		String s2[] = str.split(" ");
		for(int i=s2.length-1;i>=0;i--)
			System.out.print(s2[i]+" ");
		
		System.out.println();
		
		for(String s:s2)
			System.out.print(new StringBuilder(s).reverse()+" ");
		
//		String length with spaces
		System.out.println("\n"+str.length());
		
//		String length without spaces(" ")
		System.out.println(new StringBuilder(str.replace(" ", "")).length());
	}
}
