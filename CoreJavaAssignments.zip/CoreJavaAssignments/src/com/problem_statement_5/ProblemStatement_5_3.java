package com.problem_statement_5;

public class ProblemStatement_5_3 {
	public static void main(String[] args) {
		String str="MPHASIS";
		for(int i=0;i<str.length();i++)
		{
			for(int j=i;j<str.length();j++)
				System.out.print(str.charAt(j));
			for(int k=0;k<i;k++)
				System.out.print(str.charAt(k));
			System.out.println();
		}
		System.out.print(str);
			
	}
}
