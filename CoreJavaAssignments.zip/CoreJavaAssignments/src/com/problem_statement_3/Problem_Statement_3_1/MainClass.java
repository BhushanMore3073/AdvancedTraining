package com.problem_statement_3.Problem_Statement_3_1;

import java.util.Scanner;

public class MainClass {
	public static void main(String[] args) {
		Instrument i[] = new Instrument[10];
		
		for(int k=0;k<i.length;k++)
		{
			System.out.println("choose instrument from bellow list");
			System.out.println("1.)Piano\n2.)Flute\n3.)Guitar");
			switch(new Scanner(System.in).nextInt())
			{
				case 1:
					i[k]=new Piano();
					break;
				case 2:
					i[k]=new Flute();
					break;
				case 3:
					i[k]=new Guitar();
					break;
			}
		}
		
		for(int k=0;k<i.length;k++)
		{
			i[k].play();
			System.out.println("Objcet Number : "+k+1);
		}
	}
}

class Piano extends Instrument {
	void play() {
		System.out.println("Piano is playing tan tan tan tan");
	}
}

class Flute extends Instrument {
	void play() {
		System.out.println("Flute is playing toot toot toot toot");
	}
}

class Guitar extends Instrument{
	void play() {
		System.out.println("Guitar is playing tin tin tin");
	}
}
