package com.problem_statement_3.Problem_Statement_3_1;

public abstract class Instrument {
	abstract void play();
}
