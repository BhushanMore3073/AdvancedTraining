package com.problem_statement_3.Problem_Statement_3_2;

public class TestMedicine {
	public static void main(String[] args) {
		MedicineInfo i[] = new MedicineInfo[10];
		
		for(int k=0;k<i.length;k++)
		{
			switch((int)Math.floor(Math.random()*(3-1+1)+1))
			{
				case 1:
					i[k]=new Tablet();
					System.out.println("Tablet Selected");
					break;
				case 2:
					i[k]=new Syrup();
					System.out.println("Syrup Selected");
					break;
				case 3:
					i[k]=new Ointment();
					System.out.println("Ointment Selected");
					break;
			}
		}
		
		for(int k=0;k<i.length;k++)
			i[k].displayLable();
	}
}

class Tablet implements MedicineInfo{
	public void displayLable() {
		System.out.println("store in a cool dry place");
	}
}

class Syrup implements MedicineInfo{
	public void displayLable() {
		System.out.println("temporarily treat cough, chest congestion, and stuffy nose symptoms");
	}
}

class Ointment implements MedicineInfo{
	public void displayLable() {
		System.out.println("for external use only");
	}
}