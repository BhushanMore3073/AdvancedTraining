package com.problem_statement_3.Problem_Statement_3_2;

public interface MedicineInfo {
	void displayLable();
}
