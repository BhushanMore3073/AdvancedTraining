package com.problem_statement_7.Problem_Statement_7_2;

class NameNotValidException extends Exception
{
     public String validname()
     {
          return ("Name is not Valid..Please Re-Enter the Name");
     }
}